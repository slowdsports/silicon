<?php
// Mostramos los partidos utilizando la liga filtrada
if (isset($_GET['liga'])) {
    include('inc/football/partidos.php');
} // Mostramos las ligas con partidos disponibles
else {
    include('inc/football/lista.php');
}
?>
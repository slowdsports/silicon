<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="cache-control" content="max-age=0" />
<meta http-equiv="cache-control" content="no-cache" />
<meta http-equiv="expires" content="0" />
<meta http-equiv="expires" content="Tue, 01 Jan 1980 1:00:00 GMT" />
<meta http-equiv="pragma" content="no-cache" />
<meta name="robots" content="noindex" />
<meta name="referrer" content="none">
<script src="//cdn.bitmovin.com/player/web/8/bitmovinplayer.js"></script>
<script src="//cdn.jsdelivr.net/npm/clappr@latest/dist/clappr.min.js"></script>
<script src="//cdn.jsdelivr.net/npm/level-selector@latest/dist/level-selector.min.js"></script>
<script src="//cdn.jsdelivr.net/npm/clappr-pip@latest/dist/clappr-pip.min.js"></script>
<script src="//cdn.jsdelivr.net/gh/clappr/dash-shaka-playback@latest/dist/dash-shaka-playback.min.js"></script>
<script src='//cdn.jsdelivr.net/npm/clappr-chromecast-plugin@latest/dist/clappr-chromecast-plugin.min.js'></script>
<script src='//cdn.jsdelivr.net/npm/clappr-pip@latest/dist/clappr-pip.min.js'></script>
<script src="//ewwink.github.io/clappr-youtube-plugin/clappr-youtube-plugin.js"></script>
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
<script src="//ssl.p.jwpcdn.com/player/v/8.24.0/jwplayer.js"></script>
<script>jwplayer.key = 'XSuP4qMl+9tK17QNb+4+th2Pm9AWgMO/cYH8CI0HGGr7bdjo';</script>

<style>
    body {
        background-color: #000;
        color: #fff;
        margin: 0;
        padding: 0;
    }

    h1 {
        text-align: center;
    }

    .container {
        width: 100% !important;
        height: 100vh !important;
    }

    #player,
    #iframe {
        height: 100% !important;
        width: 100% !important;
        border: none;
    }

    .bmpui-ui-watermark {
        display: none;
    }

    .bmpui-ui-volumeslider .bmpui-seekbar .bmpui-seekbar-playbackposition-marker {
        background-color: #1487fa;
    }

    .bmpui-ui-seekbar .bmpui-seekbar .bmpui-seekbar-playbackposition,
    .bmpui-ui-volumeslider .bmpui-seekbar .bmpui-seekbar-playbackposition {
        background-color: #1487fa;
    }

    .bmpui-ui-seekbar .bmpui-seekbar .bmpui-seekbar-playbackposition-marker,
    .bmpui-ui-volumeslider .bmpui-seekbar .bmpui-seekbar-playbackposition-marker {
        border-color: #1487fa;
        background-color: #1487fa;
    }
</style>
<?php
$canal = $_GET['c'];
include('../../inc/conn.php');
if (isset($canal)) {
    $query = mysqli_query($conn, "SELECT * FROM canales
    INNER JOIN tipos ON canales.canalTipo = tipos.tipoId
    INNER JOIN categorias ON canales.canalCategoria = categorias.categoriaId
    WHERE canalId='" . $canal . "'");
    $result = mysqli_fetch_assoc($query);
    $canalId = $result['canalId'];
    $canalNombre = $result['canalNombre'];
    $canalUrl = $result['canalUrl'];
    $key1 = $result['key'];
    $key2 = $result['key2'];
    $canalImg = $result['canalImg'];
    $canalCategoria = $result['canalCategoria'];
    $canalPais = $result['canalPais'];
    $canalTipo = $result['canalTipo'];
}
// Si el tipo es CK
if ($canalTipo == 9) {
    // Canales DTV
    if (strpos($canalUrl, "//dtvott-") !== false || strpos($canalUrl, ".dtvott") !== false) {
        // JW o Bit
        if (strpos($canalUrl, "-vos") !== false || $canalId == 59) {
            $ext = "gg";
        } else {
            $ext = "bit";
        }
        // Encriptamos la URL
        $base = "";
        $canalUrl = $base . $canalUrl;
        $canalUrl = base64_encode($canalUrl);
        ?>
        <script>
            let getURL = "<?= $canalUrl ?>";
            let getKEY = "<?= $key1 ?>";
            let getKEY2 = "<?= $key2 ?>";
            let getTYPE = "<?= $canalTipo ?>";
            let getEXT = "<?= $ext ?>";
        </script>
        <div class="container">
            <iframe id="iframe" src allow="encrypted-media" allowfullscreen></iframe>
        </div>
        <script src="../../assets/js/reproductores/dtv.js"></script>
        <?php
    } else {
        // Requieren JW
        if (strpos($canalUrl, "dazn-cdn") ||strpos($canalUrl, "livewwdazn") || strpos($canalUrl, "director.streaming") || strpos($canalUrl, "izzigo.") || strpos($canalUrl, "vidgo.com")) {
            // Vidgo Requiere Proxy
            if (strpos($canalUrl, "vidgo.com")) {
                $canalUrl = "https://slowdus.herokuapp.com/" . $canalUrl;
            }
            // Encriptamos la URL
            $canalUrl = base64_encode($canalUrl); ?>
            <script>
                let getURL = "<?= $canalUrl ?>";
                let getKEY = "<?= $key1 ?>";
                let getKEY2 = "<?= $key2 ?>";
                let getTYPE = "<?= $canalTipo ?>";
            </script>
            <div class="container">
                <div id="player"></div>
            </div>
            <script src="../../assets/js/reproductores/jw.js"></script>
            <?php
        } else {
            // Encriptamos la URL
            $canalUrl = base64_encode($canalUrl); ?>
            <script>
                let getURL = "<?= $canalUrl ?>";
                let getKEY = "<?= $key1 ?>";
                let getKEY2 = "<?= $key2 ?>";
                let getTYPE = "<?= $canalTipo ?>";
            </script>
            <div class="container">
                <div id="player"></div>
            </div>
            <script src="../../assets/js/reproductores/bit.js"></script>

        <?php }
    }
} else {
    // Encriptamos la URL
    $canalUrl = base64_encode($canalUrl); ?>
    <script>
        let getURL = "<?= $canalUrl ?>";
        let getKEY = "<?= $key1 ?>";
        let getKEY2 = "<?= $key2 ?>";
        let getTYPE = "<?= $canalTipo ?>";
    </script>
    <div class="container">
        <div id="player"></div>
    </div>
    <script src="../../assets/js/reproductores/bit.js"></script>

<?php }
?>